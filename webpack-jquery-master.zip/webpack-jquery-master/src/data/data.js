var data={
  header_name:'头部',
  footer_name:'尾部'
}
export {data}

var $ = require("jquery");
$('.b_v').css('color','yellow');
require('@/components/header/header.js')//引入header组件
require('@/components/footer/footer.js')//引入footer组件

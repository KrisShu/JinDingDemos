module.exports = {
    plugins: {
        'autoprefixer': {},
      //  'postcss-px2rem': {remUnit: 100}
    }
}

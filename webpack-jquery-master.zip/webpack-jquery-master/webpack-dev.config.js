'use strict';

var webpack_config = require('./webpack.config.allinone')

module.exports = webpack_config({debug:true})
